// Shared across all Ventrox pages. Each block checks the element exists
// first, so this one file works whether or not a given page has a
// contact form or hero section.

const YOUR_EMAIL = 'you@example.com'; // <-- replace with your real email

// Contact form (contact.html) — opens the visitor's email client.
// This is a static site with no backend server, so there's nothing to
// fetch() to. If you want real form submissions landing in an inbox
// instead, sign up free at https://formspree.io and swap this handler
// for a fetch() POST to your form endpoint.
const form = document.getElementById('contact-form');
if (form) {
  const status = document.getElementById('form-status');

  form.addEventListener('submit', (e) => {
    e.preventDefault();

    const name = form.name.value.trim();
    const email = form.email.value.trim();
    const message = form.message.value.trim();

    const subject = encodeURIComponent(`New message from ${name}`);
    const body = encodeURIComponent(`${message}\n\n— ${name} (${email})`);

    status.textContent = 'Opening your email client…';
    window.location.href = `mailto:${YOUR_EMAIL}?subject=${subject}&body=${body}`;

    setTimeout(() => {
      status.textContent = 'If your email app didn\'t open, email us directly at ' + YOUR_EMAIL;
    }, 1200);
  });
}
